#include <16F877A.h>
#FUSES XT, NOWDT, NOPROTECT, NOBROWNOUT, NOLVP, NOPUT, NODEBUG, NOCPD
#use delay(crystal=16000000)
#use rs232 (baud=9600,xmit=PIN_C6, rcv=PIN_C7, parity=N, stop=1) // configuretion for serial communication

void main()
{
   setup_psp(PSP_DISABLED);
   setup_timer_1(T1_DISABLED);
   setup_timer_2(T2_DISABLED,0,1);
   setup_adc_ports(NO_ANALOGS);
   setup_adc(ADC_OFF);
   setup_CCP1(CCP_OFF);
   setup_CCP2(CCP_OFF);
   int16 dt = 1000;

   while(1)
   {
   

      printf("5");
      delay_ms(dt);
      printf("*");
      delay_ms(dt);
      printf("1");
      delay_ms(dt);
      printf("2");
      delay_ms(dt);
      printf("#");
      delay_ms(dt);
    }
      
}
